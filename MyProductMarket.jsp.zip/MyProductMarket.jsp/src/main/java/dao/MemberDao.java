package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dto.Member;

public class MemberDao {
	ResultSet rs; 
    Connection conn;
    PreparedStatement pstmt;
    
	public MemberDao() {    
		String dbID = "root";
	    String dbPassword = "7517";
	    String dbURL = "jdbc:mariadb://localhost:3310/my_product_market";
	    try{   		
		    Class.forName("org.mariadb.jdbc.Driver");
		    conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		    System.out.println("db connect successed!!");
	    }catch(Exception e){
	    	e.printStackTrace();
	    	System.out.println("db connect failed");
	   	}
	}
	
	public int insertMember(Member dto) {
		int insertRowCount = 0;
		try {
			String sql = "insert into member values(?,?,?,?,?,?,?,?,now())";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPassword());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getGender());
			pstmt.setString(5, dto.getBirth());
			pstmt.setString(6, dto.getMail());
			pstmt.setString(7, dto.getMail());
			pstmt.setString(8, dto.getAddress());
			insertRowCount = pstmt.executeUpdate();
			pstmt.close();
			conn.close();
			System.out.println("insertMember 성공!");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("insertMember 실패ㅠㅠ");
		}
		return insertRowCount;
	}
}
